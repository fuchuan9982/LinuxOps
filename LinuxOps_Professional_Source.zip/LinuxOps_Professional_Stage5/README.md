# LinuxOps Professional（统一源码交付包）

本包将此前阶段 1–5 的重复源码合并为一个标准 Maven 项目，保留一份主程序和一套模块源码。

## 环境要求

- Windows 10/11（桌面运行目标）
- JDK 21
- Maven 3.9+
- 目标 Linux 主机启用 SSH；首次连接前须核验并配置 Windows 用户目录下的 `~/.ssh/known_hosts`

## 构建

在本目录打开 PowerShell 或终端：

```powershell
mvn -B clean package
```

成功后生成：`target/linuxops-1.0.0.jar`

运行：

```powershell
java -jar target/linuxops-1.0.0.jar
```

Windows 便携应用由 GitHub Actions 的 `.github/workflows/windows-build.yml` 在 Windows runner 上通过 `jpackage --type app-image` 构建。当前工作流产物是 app-image 目录，下载后运行其中的 `LinuxOps.exe`；不是传统安装向导。

## 当前源码结构

```text
src/main/java/com/linuxops/
├── Main.java                    # Swing 主界面（当前接入服务器管理、批量巡检、取消和报告导出）
├── model/Host.java              # 服务器模型及唯一标识
├── security/CredentialSnapshot.java
├── task/                        # 有界批量任务、状态、结果和取消
├── inspection/                  # 巡检命令、解析、分级、SSH 采集服务
├── report/ReportExporter.java   # HTML / CSV 报告
└── ssh/SshOperations.java      # SSH 命令、软件安装、systemd、SFTP 服务层
```

## 已纳入的能力

- 服务器手动添加、CSV 导入、选择、删除；唯一标识包含主机、端口和用户名
- 有界并发任务调度、分批执行、进度回调和取消令牌
- SSH `known_hosts` 校验、连接超时、密码副本清理
- 结构化巡检与 NORMAL / WARNING / CRITICAL 分级
- HTML、CSV 巡检报告
- SSH 命令、APT/DNF/YUM 安装、systemd 操作、SFTP 上传/下载服务接口
- Windows GitHub Actions app-image 构建工作流

## 尚未完成 / 使用前须知

**这是统一开发源码包，不应误认为已经完成生产验收的最终产品。** `SshOperations` 已纳入项目，但当前 `Main.java` 的界面按钮尚未全部接入该服务；实时监控界面、服务器分组持久化、集中审计、完整任务列表、凭据保险库仍需开发。SSH 命令输出目前采用命令结束后读取流的方式，大输出场景仍需改为并行消费 stdout/stderr。

当前没有完成完整 Maven + SSHJ 联合构建、Windows app-image 实际运行、Ubuntu/Rocky/Debian 真实主机测试或 100–500 台压力测试。请先在测试环境构建和验证，勿直接执行生产变更。

## CSV 格式

见 `hosts_example.csv`，列顺序为 `group,name,host,port,user`。当前导入器按逗号简单拆分，不支持带引号的逗号字段。

## 安全建议

- 首次连接前通过可信渠道核验 SSH 主机指纹；不要关闭主机密钥校验。
- 优先使用 SSH 密钥和最小权限账户。
- 批量安装、服务变更、重启前必须由操作者确认，并配置受控的免交互 sudo 权限。
- 不要把密码、私钥或生产主机敏感信息提交到 Git 仓库。
