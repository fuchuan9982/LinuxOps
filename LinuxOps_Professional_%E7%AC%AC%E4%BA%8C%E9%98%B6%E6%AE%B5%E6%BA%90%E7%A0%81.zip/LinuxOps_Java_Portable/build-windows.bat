@echo off
setlocal
chcp 65001 >nul
echo [1/3] 检查 Java 21 与 Maven...
where java >nul 2>nul || (echo 未检测到 Java。请在构建机安装 JDK 21。& pause & exit /b 1)
where mvn >nul 2>nul || (echo 未检测到 Maven。请在构建机安装 Maven 3.9+。& pause & exit /b 1)
echo [2/3] 编译打包...
call mvn -DskipTests clean package
if errorlevel 1 (echo Maven 构建失败。& pause & exit /b 1)
echo [3/3] 使用 jpackage 生成含 Java 运行时的便携目录...
if exist dist rmdir /s /q dist
jpackage --type app-image --name LinuxOps --input target --main-jar linuxops-1.0.0.jar --main-class com.linuxops.Main --dest dist --vendor "LinuxOps"
if errorlevel 1 (echo jpackage 失败。& pause & exit /b 1)
echo.
echo 构建完成：dist\LinuxOps\LinuxOps.exe
echo 将整个 dist\LinuxOps 文件夹复制到目标电脑，双击 LinuxOps.exe 即可运行。
pause
